<html>
<head>
<?php include('daves_canvas.php'); ?>
<?php include('css/daves_css.php'); ?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Doap.com Canvas Template</title>
</head>

<body onload="drawCanvas();" >
<h1>Use this page to experiment with HTML5 Canvas</h1>
<div id="doap_canvas"><canvas id="doapify" width="1050" height="510"></canvas></div>
</body>
</html>